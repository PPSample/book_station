<html>
<head>
<title>login</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<?php
if(isset($_post["login"]))
{
$email=$_post["email"];
$password=$_post["password"];
require_once "database.php";
$sql="select * from users where email='$email'";
$result=mysqli_query($conn,$sql);
$user=mysqli_fetch_array($result,mysqli_assoc);
if($user)
{
 if(password_verify($password,$user["password"])
{
header("location:index.php");
die();
}
}
else
{
echo "<div class='alert alert-danger'>email does not match</div>
}
}
?>
<form action="login.php" method="post">
<div class="form-group">
 <input type="email" placeholder="enter email" name="email" class="form-control">
</div>
<div class="form-group">
 <input type="password" placeholder="enter password" name="password" class="form-control">
</div>
<div class="form-btn">
 <input type="submit" value="login" name="login" class="btn btn-primary">
</div>
</form>
</div>
</body>
</html>
